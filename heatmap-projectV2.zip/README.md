# Heatmap Project

This project was generated with [angular-cli](https://github.com/angular/angular-cli) version 1.0.0-beta.28.3.

This project assumes that MongoDB is running locally

## Start Server
Run `yarn install` and then `node server.js`. Navigate to `http://localhost:3000/`

This will allow you to create a polygon that will display a heat map for median income. For performance, all values are stored to local storage.