export class Button {
  type: string;
  color: string;
  icon: string;
  onClick: void;
}
