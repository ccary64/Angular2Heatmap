export class MapConfig {
  zoom = 14;
  gridSize = 0.001;
  apiKey = 'AIzaSyA0YYB5jo5aKUkQdFWWbmxPSzE83LxfL6Y';
}
